Original CC0 mesh with two primitives/materials, UV0 and UV1, repeated UVs [0,8], external PNG.
